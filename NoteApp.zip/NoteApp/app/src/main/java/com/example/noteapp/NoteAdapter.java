package com.example.noteapp;

import android.content.ClipData;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NoteAdapter extends RecyclerView.Adapter<NoteAdapter.NoteViewHolder> {

    private List<Note> notes = new ArrayList<>();

    static class NoteViewHolder extends RecyclerView.ViewHolder {
        ItemNoteBinding binding;

        NoteViewHolder(ItemNoteBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemNoteBinding binding = ItemNoteBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new NoteViewHolder(binding);
    }

    @RequiresApi(api = Build.VERSION_CODES.VANILLA_ICE_CREAM)
    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Note note = notes.get(position);
        holder.binding.noteContent.setText(note.getContent());
        ClipData.Item.Builder builder = holder.binding.timestamp.setText(DateFormat.getDateTimeInstance().format(new Date(note.getTimestamp())));
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    public void setNotes(List<Note> newNotes) {
        notes = newNotes;
        notifyDataSetChanged();
    }

    private static class ItemNoteBinding {
        public ClipData.Item.Builder noteContent;
        public ClipData.Item.Builder timestamp;

        public static ItemNoteBinding inflate(LayoutInflater from, ViewGroup parent, boolean b) {
            return null;
        }

        public View getRoot() {
            return null;
        }
    }
}

